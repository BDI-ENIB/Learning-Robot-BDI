#ifndef MODULES
#define MODULES
#include "src/summerbot-actionneurs/simple-crane.hpp"
#include <Servo.h>

namespace Modules{
SimpleCrane *simplecrane;
}


#endif
